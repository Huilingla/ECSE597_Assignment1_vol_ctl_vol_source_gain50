% CompareOpAmps.m
% Clear environment
clear; clc; clear global;

% 1. Run finite gain simulation (Gain = 50)
filter_netlist; % This is your original netlist using vcvs
[f, v_finite] = fsolve(1, 2000, 500, 10);

% Clear globals before running the second netlist to prevent matrix mixing
clear global G C b; 
global G C b;

% 2. Run ideal op-amp simulation
filter_netlist_ideal; % This is the updated netlist using opa
[~, v_ideal] = fsolve(1, 2000, 500, 10);

% 3. Generate the Plots
figure;

% Plot 1: Finite Gain
subplot(2,1,1);
loglog(f, v_finite, 'r', 'LineWidth', 1.5);
grid on;
title('Frequency Response: VCVS with Gain=50');
xlabel('Frequency (Hz)');
ylabel('|V_{out}|');

% Plot 2: Ideal Op-Amp
subplot(2,1,2);
loglog(f, v_ideal, 'b', 'LineWidth', 1.5);
grid on;
title('Frequency Response: Ideal Op-Amp');
xlabel('Frequency (Hz)');
ylabel('|V_{out}|');

% 4. Generate the Plots Together
figure;
loglog(f, v_finite, 'r--', 'LineWidth', 1.5); hold on;
loglog(f, v_ideal, 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Frequency (Hz)');
ylabel('|V_{out}|');
title('Frequency Response: VCVS (Gain=50) vs. Ideal Op-Amp');
legend('VCVS Model (Gain=50)', 'Ideal Op-Amp Model');